package infrastusture.generators;

public interface Generator<T> {
    T generate();
}
